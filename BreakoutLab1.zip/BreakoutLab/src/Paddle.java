import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.geom.Rectangle2D;
import java.util.List;

public class Paddle extends GameObject implements ICollidable {
  private static final int WIDTH = 100;
  private static final int HEIGHT = 20;

  private double velX;
  private double velY;
  private KeyAdapter input;

  // Constructor
  Paddle(double x, double y) {
    // Call the superclass constructor with x, y, width, and height
    super(x, y, WIDTH, HEIGHT);
    this.input = new PaddleKeyAdapter(this);
  }

  // Update paddle position
  @Override
  public void update() {
    this.setX(this.getX() + this.velX);
    this.setY(this.getY() + this.velY);
  }

  // Render the paddle
  @Override
  public void render(Graphics2D g2d) {
    g2d.setColor(Color.YELLOW);
    Shape p = new Rectangle2D.Double(this.getX(), this.getY(), this.getWidth(), this.getHeight());
    g2d.fill(p);
  }

  // Get the input handler
  KeyAdapter getInput() {
    return this.input;
  }

  // Implementations of ICollidable methods
  @Override
  public boolean isPaddle() {
    return true;
  }

  @Override
  public boolean isBall() {
    return false;
  }

  @Override
  public boolean isBrick() {
    return false;
  }

  @Override
  public void handleCollision(List<GameObject> ls) {
    // Custom collision handling logic (if needed)
  }

  // Velocity accessors and mutators
  public double getVelX() {
    return velX;
  }

  public void setVelX(double velX) {
    this.velX = velX;
  }

  public double getVelY() {
    return velY;
  }

  public void setVelY(double velY) {
    this.velY = velY;
  }

  // ========================= DO NOT MODIFY THE CODE BELOW ========================= //
  private static class PaddleKeyAdapter extends KeyAdapter {

    private Paddle p;

    PaddleKeyAdapter(Paddle p) {
      this.p = p;
    }

    @Override
    public void keyPressed(KeyEvent e) {
      super.keyPressed(e);
      switch (e.getKeyCode()) {
        case KeyEvent.VK_LEFT:
          this.p.setVelX(-5);
          break;
        case KeyEvent.VK_RIGHT:
          this.p.setVelX(+5);
          break;
      }
    }

    public void keyReleased(KeyEvent e) {
      super.keyPressed(e);
      switch (e.getKeyCode()) {
        case KeyEvent.VK_LEFT:
        case KeyEvent.VK_RIGHT:
          this.p.setVelX(0);
      }
    }
  }
}
